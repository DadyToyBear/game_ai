8 ТИПАЖЕЙ РЫБАКОВ ДЛЯ ИГРЫ WORLDOFVIKINGCRAFT (БЕЗ ПРЕДМЕТОВ В РУКАХ, RGBA)
================================================================================

Формат: RGBA PNG (100% прозрачный фон без белого ореола).
Стиль: средневековый мультяшный реализм в деталях (WorldOfVikingCraft).
Все 8 персонажей в полный рост, в развороте 3/4 вправо, руки полностью ПУСТЫЕ (под любую удочку).

1. Общий прозрачный лист всех 8 типажей (2480x2160 px RGBA, сетка 2x4):
   - fishermen_v2_sheets/fishermen_8_archetypes_transparent.png

2. 8 отдельных спрайтов (пропорциональный рост 865–990 px RGBA):
   - fishermen_v2_art/01_lean_man_35.png             (Взрослый худой мужик 30–40 лет)
   - fishermen_v2_art/02_plump_elder_68.png          (Пожилой толстый дед 65–70 лет)
   - fishermen_v2_art/03_young_husky_guy_20.png      (Молодой здоровый парень ~20 лет)
   - fishermen_v2_art/04_longlegged_blonde.png       (Длинноногая блондинка)
   - fishermen_v2_art/05_thin_elder_woman.png        (Пожилая худая женщина)
   - fishermen_v2_art/06_stout_redhead_woman.png     (Толстая рыжеволосая тётка)
   - fishermen_v2_art/07_young_brunette_22.png       (Молодая брюнетка ~22 лет)
   - fishermen_v2_art/08_stocky_middle_fisherman.png (Коренастый бывалый мужик-викинг)

3. Бонусный лист круговых ракурсов (спереди/сзади RGBA):
   - fishermen_v2_turnarounds/08_stocky_middle_fisherman.png
