СРЕДНЕВЕКОВЫЕ УДИЛИЩА С КАТУШКОЙ (БАМБУК И ОРЕШНИК: 2.5М, 4М, 6М, 8М) — WORLDOFVIKINGCRAFT
==================================================================================================

Формат: RGBA PNG (100% прозрачный фон без белого ореола, тонкие вершинки, деревянно-латунная инерционная катушка и пропускные кольца).

1. Сводные листы (по 4 удочки в масштабе 2.5м : 4м : 6м : 8м, 1600x2400 px RGBA):
   - rods_reel_sheets/bamboo_4_rods_reel_transparent.png  (Бамбук с катушкой: 2.5м, 4м, 6м, 8м)
   - rods_reel_sheets/hazel_4_rods_reel_transparent.png   (Орешник с катушкой: 2.5м, 4м, 6м, 8м)

2. Отдельные спрайты высокого разрешения (комель внизу, вершинка вверх):
   - rods_reel_individual/bamboo_2_5m.png, bamboo_4m.png, bamboo_6m.png, bamboo_8m.png
   - rods_reel_individual/hazel_2_5m.png, hazel_4m.png, hazel_6m.png, hazel_8m.png
