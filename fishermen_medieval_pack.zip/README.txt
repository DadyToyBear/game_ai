ПЕРСОНАЖИ-РЫБАКИ ДЛЯ ИГРЫ WORLDOFVIKINGCRAFT (8 ПЕРСОНАЖЕЙ, БЕЗ ПРЕДМЕТОВ В РУКАХ)
======================================================================================

Формат: RGBA PNG (100% прозрачный фон без белого ореола).
Стиль: средневековый скандинавско-славянский RPG, детальный мультяшный реализм.
Все персонажи в полный рост, в едином развороте 3/4 вправо, руки полностью ПУСТЫЕ (под любую удочку).

1. Общий лист всей гильдии (2480x2160 px RGBA, 2x4):
   - fishermen_sheets/fishermen_8_guild_transparent.png

2. 8 отдельных спрайтов персонажей (высота 960 px RGBA):
   - fishermen_art/01_novice_peasant.png        (Юный сельский рыболов-подмастерье)
   - fishermen_art/02_viking_veteran.png        (Бородатый рыбак-викинг)
   - fishermen_art/03_fisherwoman_nordic.png    (Рыбачка-скандинавка с косами)
   - fishermen_art/04_river_elder.png           (Дед-речник / старый мастер)
   - fishermen_art/05_winter_burbot_hunter.png  (Зимний охотник на налима в тулупе)
   - fishermen_art/06_guild_master.png          (Мастер рыболовной гильдии)
   - fishermen_art/07_coastal_skiff_sailor.png  (Лодочник / прибрежный моряк)
   - fishermen_art/08_herbal_pond_keeper.png    (Рыбачка-травница тихих заводей)

3. Бонус (круговые ракурсы спереди/сзади на прозрачном фоне RGBA):
   - fishermen_turnarounds/03_fisherwoman_nordic.png (4 ракурса)
   - fishermen_turnarounds/04_river_elder.png        (3 ракурса)
